% test_all_transmission.m

list = {
	'trl_curvature test'
	'tpl_pcg_test'
	'tml_os_sps_test'
	'tql_os_sps_test'
	'tpl_os_sps_test'
	'tml_bitab_vs_sps'
	'tml_convex_vs_sps'
	'tml_os_mltr_test'
};

run_mfile_local(list)
