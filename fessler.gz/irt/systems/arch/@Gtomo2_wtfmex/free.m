 function free(ob)
%function free(ob)
% free static memory associated with object

disp('freeing Gwtfmex object static memory')
%wtfmex('free');
