 function spy(ob)

plot(0,0, '.')
xlabel('spy not done')
