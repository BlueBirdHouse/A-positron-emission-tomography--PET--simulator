 function free(ob)
%function free(ob)
% free static memory associated with object

disp('freeing Gtomo3 object static memory')
f3d_mex('free');
