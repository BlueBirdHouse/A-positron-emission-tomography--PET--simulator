 function s = sum(ob)
%function s = sum(ob)
%	"sum" method for Gblock object

s = sum(ob.base);
