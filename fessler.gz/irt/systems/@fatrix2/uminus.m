 function b = uminus(a)
%function b = uminus(a)
% unary minus method for this class

b = (-1) * a;
