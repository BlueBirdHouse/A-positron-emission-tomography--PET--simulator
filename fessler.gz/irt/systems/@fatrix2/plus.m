 function c = plus(a, b)
%function c = plus(a, b)
% "plus" method for this class

c = fatrix2_block_sum({a, b});
