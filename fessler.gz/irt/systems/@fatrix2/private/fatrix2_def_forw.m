 function y = fatrix2_def_forw(M, x)
%function y = fatrix2_def_forw(M, x)
%| basic default 'forw' function: M * x
y = M * x;
