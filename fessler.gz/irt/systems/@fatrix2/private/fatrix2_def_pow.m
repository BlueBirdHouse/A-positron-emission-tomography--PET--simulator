 function ob = fatrix2_def_pow(M, p)
%function ob = fatrix2_def_pow(M, p)
%| basic default 'pow' function: M .^ p
ob = M .^ p;
