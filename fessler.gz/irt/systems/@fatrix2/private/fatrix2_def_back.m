 function x = fatrix2_def_back(M, y)
%function x = fatrix2_def_back(M, y)
%| basic default 'back' function: M' * y
x = M' * y;
