 function c = minus(a, b)
%function c = minus(a, b)
% "minus" method for this class

c = a + (-1 * b);
