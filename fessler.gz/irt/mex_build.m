% mex_build
% some of the functions in this toolbox use calls to mex files.
% the source code for *some*, but not all, of those mex files
% is included with the toolbox.
% the compiled mex files are available for several supported system types
% in the mex directory.  for unsupported systems, e.g., PCs, the user
% will have to comiple her own mex files using this script.

mex_build_mri
mex_build_table
% todo: mex_build_penal
