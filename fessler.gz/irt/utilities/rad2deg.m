 function d = rad2deg(r)
%function d = rad2deg(r)
% Convert from radians to degrees.

d = r*180/pi;
