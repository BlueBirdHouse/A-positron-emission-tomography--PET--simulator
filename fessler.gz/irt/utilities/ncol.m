function n = ncol(x)

%	function n = ncol(x)
%	Return number of columns in x.

	n = size(x); n = n(2);
